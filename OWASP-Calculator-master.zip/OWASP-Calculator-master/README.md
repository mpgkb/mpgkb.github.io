<div align="center">
  <h1>OWASP Risk Assessment Calculator</h1>

  <h4>🧮 An online calculator to assess the risk of web vulnerabilities based on OWASP Risk Assessment.</h4>

<a align="center" href="https://javierolmedo.github.io/OWASP-Calculator/" target="_blank">GO TO ONLINE CALCULATOR</a>

![](https://raw.githubusercontent.com/JavierOlmedo/OWASP-Calculator/master/img/orac.gif)

> _Made with ❤️ in Spain_

</div>
